const fs = require('fs');
const express = require('express');
const expressLayouts = require('express-ejs-layouts');
const path = require('path');
const mysql = require('mysql2')
const bodyParser = require('body-parser');
const jwt = require('jsonwebtoken');
const moment = require('moment');
const multer = require('multer');
const bcrypt = require('bcrypt');
const cookieParser = require('cookie-parser');

const router = express()

//buat folder penampung file jika tidak ada
if (!fs.existsSync('./uploads')) {
  fs.mkdirSync('./uploads');
}


router.set('view engine', 'ejs')
router.set('views', path.join(__dirname, 'views'))
router.set('views', './views');
router.use(expressLayouts)
router.use('/css', express.static(path.resolve(__dirname, "public/css")));
router.use('/img', express.static(path.resolve(__dirname, "public/img")));


// middleware untuk parsing request body
router.use(bodyParser.urlencoded({ extended: false }));
router.use(bodyParser.json());
router.use(cookieParser());

//saltround
const saltRounds = 10;

// koneksi database
const db = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  database: 'db_course'
});

//cek apakah sudah konek, kalau belum kasih info error
db.connect((err)=>{
  if(err) throw err
  console.log('database terkoneksi')
})

//GET 
router.get('/login', function (req, res) {
  res.render('login',{
    title:'login',
    layout:'layouts/auth-layout'
  })
})

router.get('/register', function (req, res) {
  res.render('register',{
    title:'register',
    layout:'layouts/auth-layout'
  })
})



// index page
router.get('/', requireAuth, function (req, res) {
  if (!req.user_id) {
    res.redirect('/login');
    return;
  }
  let user_id = req.user_id;
  const selectSql = `SELECT * FROM users WHERE user_id = ${user_id}`;
  db.query(selectSql, (err,result)=>{
    if (err) throw err;
    // Periksa apakah user sudah login dan aktif
    if (result[0].active === 0) {
      res.render('index',{
        user: result[0],
        title:'home',
        layout:'layouts/main-layout',
        // successMessage: successMessage,
        // errorMessage: errorMessage 
      });
    } else {
      // Jika user tidak aktif, arahkan kembali ke halaman login
      res.redirect('/login');
    }
  });
});



router.get('/add-form', requireAuth, function (req, res) {
  let user_id = req.user_id;
  const selectSql = `SELECT * FROM users WHERE user_id = ${user_id}`;
  db.query(selectSql, (err,result)=>{
    if (err) throw err;
    // Periksa apakah user sudah login dan aktif
    if (result[0].active === 0) {
      res.render('add-form',{
        user: result[0],
        title:'add form',
        layout:'layouts/main-layout',
        // successMessage: successMessage,
        // errorMessage: errorMessage 
      });
    } else {
      // Jika user tidak aktif, arahkan kembali ke halaman login
      res.redirect('/login');
    }
  });
})

//profil page
router.get('/profil', requireAuth, function (req, res) {
  // const successMessage = req.session.successMessage;
  // const errorMessage = req.session.errorMessage; // Menambahkan errorMessage
  // delete req.session.successMessage;
  // delete req.session.errorMessage; // Menghapus errorMessage setelah digunakan
  let user_id = req.user_id;
  const selectSql = `SELECT * FROM users WHERE user_id = ${user_id}`;
  db.query(selectSql, (err,result)=>{
    if (err) throw err;
    // Periksa apakah user sudah login dan aktif
    if (result[0].active === 0) {
      res.render('profil',{
        user: result[0],
        title:'Profil',
        layout:'layouts/main-layout'
        // successMessage: successMessage,
        // errorMessage: errorMessage 
      });
    } else {
      // Jika user tidak aktif, arahkan kembali ke halaman login
      res.redirect('/login');
    }
  });
});

//edit profil
router.get('/edit-profil', function (req, res) {
  res.render('edit-profil',{
    title:'edit profil',
    layout:'layouts/main-layout'
  })
})

//POST
//register
router.post('/register', function (req, res) {
  const { username, password, confirm_password } = req.body;

  
  const sqlCheck = 'SELECT * FROM users WHERE username = ?';
  db.query(sqlCheck, username, (err, result) => {
    if (err) throw err;

    if (result.length > 0) {
      // cek username sudah terdaftar atau belum
      return res.status(400).send('username sudah terdaftar');
    }

    if (password !== confirm_password) {
      //mencocokan password
      return res.status(400).send('password tidak cocok!');
    }

    // menghash password
    bcrypt.hash(password, saltRounds, function(err, hash) {
      if (err) throw err;

      // tambahkan user ke database
      const sqlInsert = 'INSERT INTO users (username, password) VALUES (?, ?)';
      const values = [username, hash];
      db.query(sqlInsert, values, (err, result) => {
        if (err) throw err;
        console.log('user terdaftar!');
        res.redirect('/login');
      });
    });
  });
});

//login
router.post('/login', function (req, res) {
  const { username, password } = req.body;

    const sql = 'SELECT * FROM users WHERE username = ?';
  db.query(sql, [username], function(err, result) {
      if (err) throw err;

      if (result.length === 0) {
          res.status(401).send('Invalid username or password');
          return;
      }

      const user = result[0];

      // compare password
      bcrypt.compare(password, user.password, function(err, isValid) {
          if (err) throw err;

          if (!isValid) {
              res.status(401).send('Invalid username or password');
              return;
          }

          // generate token
          const token = jwt.sign({ user_id: user.user_id }, 'secret_key');
          res.cookie('token', token, { httpOnly: true });

          res.redirect('/');
      });
   });
});

// middleware untuk memeriksa apakah user sudah login atau belum
function requireAuth(req, res, next) {
  
  const token = req.cookies.token;

  if (!token) {
    res.redirect('/login');
    return;
  }
  

  jwt.verify(token, 'secret_key', function(err, decoded) {
    if (err) {
      res.redirect('/login');
      return;
    }

    req.user_id = decoded.user_id;
    next();
  });
}





router.listen(5000,(req, res) => {
  console.log('listening on port 5000')
})